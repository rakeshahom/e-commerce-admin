package com.genius.AI_code.controller;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.genius.AI_code.model.Category;
import com.genius.AI_code.service.CategoryService;

@Controller
@RequestMapping("/e-commerce/admin/")
public class CategoryController {
	public static final String uploadDir = System.getProperty("user.dir") + "/src/main/resources/static/categoryImages";

	@Autowired
	private CategoryService categoryService;

	@GetMapping("home")
	public String adminhome() {
		return "admin/index";
	}
	

	@GetMapping("category/add")
	public String categoryAddGet(Model model) {
		model.addAttribute("category", new Category());
		return "admin/categoryAdd";
	}

	@PostMapping("category/add")
	public String categoryAddPost(@ModelAttribute("category") Category category,
			@RequestParam("categoryImage") MultipartFile file, @RequestParam("imgName") String imgName)
			throws IOException {
		category.setId(category.getId());
		category.setName(category.getName());
		String imageUUID;
		if (!file.isEmpty()) {
			imageUUID = file.getOriginalFilename();

			Path fileNameAndPath = Paths.get(uploadDir, imageUUID);
			Files.write(fileNameAndPath, file.getBytes());
		} else {
			imageUUID = imgName;
		}
		category.setImageName(imageUUID);
		categoryService.addCategory(category);
		return "redirect:add";
	}
	@GetMapping("category/delete/{id}")
	public String deleteCategory(@PathVariable int id) {
		categoryService.removCategoryById(id);
		return "redirect:/e-commerce/admin/category/manage";
	}
	@GetMapping("category/manage")
	public String categoryAddManage(Model model) {
		model.addAttribute("categories", categoryService.getAllCategories());
		return "admin/category_manage";
	}
	@GetMapping("category/update/{id}")
	public String updateCategoryGet(@PathVariable int id,Model model)
			 {
		Category category=categoryService.getCategoryById(id);
		category.setName(category.getName());
		category.setImageName(category.getImageName());
		model.addAttribute("categories", categoryService.getAllCategories());
		model.addAttribute("category",category);
		return "admin/categoryAdd";
	}
}
