package com.genius.AI_code.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.genius.AI_code.model.Role;
import com.genius.AI_code.model.User;
import com.genius.AI_code.repository.RoleRepository;
import com.genius.AI_code.repository.UserRepository;


@Controller
//@RequestMapping("/e-commerce")
public class HomeController {
	
	@Autowired
	private BCryptPasswordEncoder bCryptPasswordEncoder;
	@Autowired
	private UserRepository userRepository;

	@Autowired
	private RoleRepository roleRepository;

	@GetMapping("/")
	public String home() {
		return "user/layout";
	}
	@GetMapping("/shop")
	public String shop() {
		return "user/shop-grid.html";
	}
	@GetMapping("/login")
	public String signin(Model model) {
		model.addAttribute("title", "Sign-in");
		return "admin/pages-login";
	}

	@GetMapping("/register")
	public String register(Model model) {
		model.addAttribute("title", "Sign-up");
		model.addAttribute("user", new User());
		return "admin/pages-register";
	}
	@PostMapping("/register")
	public String register(@ModelAttribute("user")User user,HttpServletRequest request)throws ServletException{
		
			String password=user.getPassword();
			user.setPassword(bCryptPasswordEncoder.encode(password));
			List<Role>roles=new ArrayList<>();
			roles.add(roleRepository.findById(2).get());
			user.setRoles(roles);
			user.setRemember(true);
			userRepository.save(user);
			request.login(user.getUsername(), password);
			return "redirect:/";
		
	}
	@GetMapping("/admin/profile")
	public String profile() {
		return "admin/users-profile";
	}
	
}
