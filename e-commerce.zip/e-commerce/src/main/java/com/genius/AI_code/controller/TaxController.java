package com.genius.AI_code.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.genius.AI_code.model.Tax;
import com.genius.AI_code.service.TaxService;

@Controller
@RequestMapping("/e-commerce/admin/")
public class TaxController {

	@Autowired
	private TaxService taxService;

	@GetMapping("tax/add")
	public String taxAddGet(Model model) {
		model.addAttribute("tax", new Tax());
		return "admin/taxAdd";
	}

	@PostMapping("tax/add")
	public String taxAddPost(@ModelAttribute("tax") Tax tax) {
		tax.setId(tax.getId());
		tax.setTax_value(tax.getTax_value());
		tax.setTax_desc(tax.getTax_desc());
		tax.setStatus(1);
		taxService.addTax(tax);
		return "redirect:/e-commerce/admin/tax/add";
	}

	@GetMapping("tax/delete/{id}")
	public String deleteTax(@PathVariable int id) {
		taxService.removTaxById(id);
		return "redirect:/e-commerce/admin/tax/manage";
	}

	@GetMapping("tax/manage")
	public String taxAddManage(Model model) {
		model.addAttribute("taxes", taxService.getAllTax());
		return "admin/tax_manage";
	}

	@GetMapping("tax/update/{id}")
	public String updateTaxGet(@PathVariable int id, Model model) {
		Tax tax = taxService.getTaxById(id);
		tax.setTax_value(tax.getTax_value());
		tax.setTax_desc(tax.getTax_desc());
		tax.setStatus(1);
		model.addAttribute("taxes", taxService.getAllTax());
		model.addAttribute("tax", tax);
		return "admin/taxAdd";
	}

}
