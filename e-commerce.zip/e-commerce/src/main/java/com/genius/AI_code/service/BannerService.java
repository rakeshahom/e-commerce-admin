package com.genius.AI_code.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.genius.AI_code.model.Banner;
import com.genius.AI_code.repository.BannerRepository;

@Service
public class BannerService {

//	@Autowired
	private BannerRepository bannerRepository;

	public void addBanner(Banner banner) {
		// TODO Auto-generated method stub
		bannerRepository.save(banner);
	}

	public List<Banner> getAllbanner() {
		// TODO Auto-generated method stub
		return bannerRepository.findAll();
	}

	public void removbannerById(int id) {
		// TODO Auto-generated method stub
		bannerRepository.deleteById(id);
	}
	
	public Banner getbannerById(int id) {
		// TODO Auto-generated method stub
		return bannerRepository.getById(id);
	}

	
	
}
