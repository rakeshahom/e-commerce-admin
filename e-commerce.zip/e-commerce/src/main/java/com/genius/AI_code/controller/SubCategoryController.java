package com.genius.AI_code.controller;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.genius.AI_code.dto.SubCategoryDTO;
import com.genius.AI_code.model.SubCategory;
import com.genius.AI_code.service.CategoryService;
import com.genius.AI_code.service.SubCategoryService;

@Controller
@RequestMapping("/e-commerce/admin/")
public class SubCategoryController {
	public static final String uploadDir = System.getProperty("user.dir")
			+ "/src/main/resources/static/subcategoryImages";

	@Autowired
	private SubCategoryService subcategoryService;
	
	@Autowired
	private CategoryService categoryservice;
	
	@GetMapping("subcategory/add")
	public String subcategoryAddGet(Model model) {
		model.addAttribute("subCategoryDTO", new SubCategoryDTO());
		model.addAttribute("categories", categoryservice.getAllCategories());
		return "admin/subcategoryAdd";
	}

	@PostMapping("subcategory/add")
	public String subcategoryAddPost(@ModelAttribute("subCategoryDTO") SubCategoryDTO subCategoryDTO,
			@RequestParam("subcategoryImage") MultipartFile file, @RequestParam("imgName") String imgName)
			throws IOException {
		SubCategory subcategory=new SubCategory();
		subcategory.setId(subCategoryDTO.getId());
		subcategory.setName(subCategoryDTO.getName());
		subcategory.setCategory(categoryservice.getCategoryById(subCategoryDTO.getCategoryId()));
		
		String imageUUID;
		if (!file.isEmpty()) {
			imageUUID = file.getOriginalFilename();

			Path fileNameAndPath = Paths.get(uploadDir, imageUUID);
			Files.write(fileNameAndPath, file.getBytes());
		} else {
			imageUUID = imgName;
		}
		subcategory.setImageName(imageUUID);
		subcategoryService.addsubCategory(subcategory);
		return "redirect:add";
	}

	@GetMapping("subcategory/delete/{id}")
	public String deletesubCategory(@PathVariable Long id) {
		subcategoryService.removsubCategoryById(id);
		return "redirect:/e-commerce/admin/subcategory/manage";
	}

	@GetMapping("subcategory/manage")
	public String subcategoryAddManage(Model model) {
		model.addAttribute("subcategory", subcategoryService.getAllSubCategories());
		return "admin/subcategory_manage";
	}

	@GetMapping("subcategory/update/{id}")
	public String updateSubCategoryGet(@PathVariable Long id, Model model) {
		SubCategory subcategory = subcategoryService.getSubCategoryById(id).get();
		SubCategoryDTO subCategoryDTO=new SubCategoryDTO();
		subCategoryDTO.setCategoryId(subcategory.getCategory().getId());
		subCategoryDTO.setId(subcategory.getId());
		subCategoryDTO.setName(subcategory.getName());
		subCategoryDTO.setImageName(subcategory.getImageName());
		model.addAttribute("categories", categoryservice.getAllCategories());
		model.addAttribute("subCategoryDTO", subCategoryDTO);
		return "admin/subcategoryAdd";
	}

}
