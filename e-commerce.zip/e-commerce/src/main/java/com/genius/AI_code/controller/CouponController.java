package com.genius.AI_code.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.genius.AI_code.model.Coupon;
import com.genius.AI_code.service.CouponService;

@Controller
@RequestMapping("/e-commerce/admin/")
public class CouponController {

	@Autowired
	private CouponService couponService;

	@GetMapping("coupon/add")
	public String CouponAddGet(Model model) {
		model.addAttribute("coupon", new Coupon());
		return "admin/couponAdd";
	}

	@PostMapping("coupon/add")
	public String couponAddPost(@ModelAttribute("coupon") Coupon coupon) {
		coupon.setId(coupon.getId());
		coupon.setTitle(coupon.getTitle());
		coupon.setCode(coupon.getCode());
		coupon.setValue(coupon.getValue());
		coupon.setStatus(1);
		couponService.addCoupon(coupon);
		return "redirect:/e-commerce/admin/coupon/add";
	}

	@GetMapping("coupon/delete/{id}")
	public String deleteCoupon(@PathVariable int id) {
		couponService.removCouponById(id);
		return "redirect:/e-commerce/admin/coupon/manage";
	}

	@GetMapping("coupon/manage")
	public String couponAddManage(Model model) {
		model.addAttribute("coupons", couponService.getAllCoupon());
		return "admin/coupon_manage";
	}

	@GetMapping("coupon/update/{id}")
	public String updateCouponGet(@PathVariable int id, Model model) {
		Coupon coupon = couponService.getCouponById(id);
		coupon. setValue(coupon.getValue());
		coupon.setCode(coupon.getCode());
		coupon.setTitle(coupon.getTitle());
		coupon.setStatus(1);
		model.addAttribute("coupons", couponService.getAllCoupon());
		model.addAttribute("coupon", coupon);
		return "admin/couponAdd";
	}

}
