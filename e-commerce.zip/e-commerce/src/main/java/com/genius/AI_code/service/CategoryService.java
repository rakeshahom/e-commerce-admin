package com.genius.AI_code.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.genius.AI_code.model.Category;
import com.genius.AI_code.repository.CategoryRepository;

@Service
public class CategoryService {

	@Autowired
	private CategoryRepository categoryRepository;

	public void addCategory(Category category) {
		// TODO Auto-generated method stub
		categoryRepository.save(category);
	}

	public List <Category> getAllCategories() {
		// TODO Auto-generated method stub
		return categoryRepository.findAll();
	}

	public void removCategoryById(int id) {
		// TODO Auto-generated method stub
		categoryRepository.deleteById(id);
	}
	
	public Category getCategoryById(int id) {
		// TODO Auto-generated method stub
		return categoryRepository.getById(id);
	}
	
}
