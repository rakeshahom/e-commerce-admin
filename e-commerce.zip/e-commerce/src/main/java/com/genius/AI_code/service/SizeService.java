package com.genius.AI_code.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.genius.AI_code.model.Size;
import com.genius.AI_code.repository.SizeRepository;

@Service
public class SizeService {

	@Autowired
	private SizeRepository sizeRepository;

	public void addSize(Size size) {
		// TODO Auto-generated method stub
		sizeRepository.save(size);
	}

	public List<Size> getAllsize() {
		// TODO Auto-generated method stub
		return sizeRepository.findAll();
	}

	public void removsizeById(int id) {
		// TODO Auto-generated method stub
		sizeRepository.deleteById(id);
	}
	
	public Size getsizeById(int id) {
		// TODO Auto-generated method stub
		return sizeRepository.getById(id);
	}

	
	
}
