package com.genius.AI_code.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.genius.AI_code.model.Color;
import com.genius.AI_code.service.ColorService;

@Controller
@RequestMapping("/e-commerce/admin/")
public class ColorController {

	@Autowired
	private ColorService colorService;

	@GetMapping("color/add")
	public String colorAddGet(Model model) {
		model.addAttribute("color", new Color());
		return "admin/colorAdd";
	}

	@PostMapping("color/add")
	public String colorAddPost(@ModelAttribute("color") Color color) {
		color.setId(color.getId());
		color.setColorname(color.getColorname());
		color.setStatus(1);
		colorService.addColor(color);
		return "redirect:/e-commerce/admin/color/add";
	}

	@GetMapping("color/delete/{id}")
	public String deleteColor(@PathVariable int id) {
		colorService.removColorById(id);
		return "redirect:/e-commerce/admin/color/manage";
	}

	@GetMapping("color/manage")
	public String colorAddManage(Model model) {
		model.addAttribute("colors", colorService.getAllColor());
		return "admin/color_manage";
	}

	@GetMapping("color/update/{id}")
	public String updateColorGet(@PathVariable int id, Model model) {
		Color color = colorService.getColorById(id);
		color.setColorname(color.getColorname());
		color.setStatus(1);
		model.addAttribute("colors", colorService.getAllColor());
		model.addAttribute("color", color);
		return "admin/colorAdd";
	}

}
