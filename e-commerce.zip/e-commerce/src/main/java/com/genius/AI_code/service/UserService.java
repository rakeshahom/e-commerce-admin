package com.genius.AI_code.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.genius.AI_code.model.User;
import com.genius.AI_code.repository.UserRepository;

@Service
	public class UserService {
		
		@Autowired
	private UserRepository repo;
		
		public void saveUser(User user) {
			repo.save(user);
		}
	}


