package com.genius.AI_code.controller;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.genius.AI_code.dto.ProductDTO;
import com.genius.AI_code.model.Product;
import com.genius.AI_code.service.BrandService;
import com.genius.AI_code.service.CategoryService;
import com.genius.AI_code.service.ColorService;
import com.genius.AI_code.service.CouponService;
import com.genius.AI_code.service.ProductService;
import com.genius.AI_code.service.SizeService;
import com.genius.AI_code.service.SubCategoryService;
import com.genius.AI_code.service.TaxService;

@Controller
@RequestMapping("/e-commerce/admin/")
public class ProductController {
	public static final String uploadDir = System.getProperty("user.dir")
			+ "/src/main/resources/static/productImages";

	@Autowired
	private ProductService productService;
	@Autowired
	private SubCategoryService subcategoryservice;
	@Autowired
	private CategoryService categoryservice;
	@Autowired
	private BrandService brandservice;
	@Autowired
	private TaxService taxservice;
	@Autowired
	private SizeService sizeservice;
	@Autowired
	private ColorService colorservice;
	@Autowired
	private CouponService couponservice;
	
	
	@GetMapping("product/add")
	public String subcategoryAddGet(Model model) {
		model.addAttribute("categories", categoryservice.getAllCategories());
		model.addAttribute("subcategories", subcategoryservice.getAllSubCategories());
		model.addAttribute("brands", brandservice.getAllBrands());
		model.addAttribute("sizes", sizeservice.getAllsize());
		model.addAttribute("colors",colorservice.getAllColor());
		model.addAttribute("coupons", couponservice.getAllCoupon());
		model.addAttribute("taxes", taxservice.getAllTax());
		model.addAttribute("productDTO", new ProductDTO());
		return "admin/productAdd";
	}

	@PostMapping("product/add")
	public String productAddPost(@ModelAttribute("productDTO") ProductDTO productDTO,
			@RequestParam("producImage") MultipartFile file, @RequestParam("imgName") String imgName)
			throws IOException {
		Product product=new Product();
		product.setId(productDTO.getId());
		
		product.setName(productDTO.getName());
		product.setPrice(productDTO.getPrice());
		product.setWeight(productDTO.getWeight());
		product.setShort_desc(productDTO.getShort_desc());
		product.setDescription(productDTO.getDescription());
		product.setTechnical_specification(productDTO.getTechnical_specification());
		product.setUses(productDTO.getUses());
		product.setKeywords(productDTO.getKeywords());
		product.setWarranty(productDTO.getWarranty());
		product.setStatus("1");
		product.setModel(productDTO.getModel());
		product.setMrp(productDTO.getMrp());
		product.setSku(productDTO.getSku());
		product.setIs_tranding(productDTO.getIs_tranding());
		product.setIs_discounted(productDTO.getIs_discounted());
		product.setIs_featured(productDTO.getIs_featured());
		product.setIs_promo(productDTO.getIs_promo());
		product.setLead_time(productDTO.getLead_time());
		product.setCategory(categoryservice.getCategoryById(productDTO.getCategoryId()));
		product.setSubcategory(subcategoryservice.getSubCategoryById(productDTO.getSubcategoryId()).get());
		product.setTax(taxservice.getTaxById(productDTO.getTaxId()));
		product.setBrand(brandservice.getbrandById(productDTO.getBrandId()));
		product.setSize(sizeservice.getsizeById(productDTO.getSizeId()));
		product.setColor(colorservice.getColorById(productDTO.getColorId()));
		product.setCouponId(couponservice.getCouponById(productDTO.getCouponId()));
		
		String imageUUID;
		if (!file.isEmpty()) {
			imageUUID = file.getOriginalFilename();

			Path fileNameAndPath = Paths.get(uploadDir, imageUUID);
			Files.write(fileNameAndPath, file.getBytes());
		} else {
			imageUUID = imgName;
		}
		product.setImageName(imageUUID);
		productService.addProduct(product);
		return "redirect:/e-commerce/admin/product/add";
	}

	@GetMapping("product/delete/{id}")
	public String deleteProduct(@PathVariable Long id) {
		productService.removProductById(id);
		return "redirect:/e-commerce/admin/product/manage";
	}

	@GetMapping("product/manage")
	public String productAddManage(Model model) {
		model.addAttribute("product", productService.getAllProducts());
		return "admin/product_manage";
	}

	@GetMapping("product/update/{id}")
	public String updateProductGet(@PathVariable Long id, Model model) {
		Product product = productService.getProductById(id);
		ProductDTO productDTO=new ProductDTO();
		productDTO.setSubcategoryId(product.getSubcategory().getId());
		productDTO.setCategoryId(product.getCategory().getId());
		productDTO.setBrandId(product.getBrand().getId());
		productDTO.setColorId(product.getColor().getId());
		productDTO.setCouponId(product.getCouponId().getId());
		productDTO.setTaxId(product.getTax().getId());
		productDTO.setSizeId(product.getSize().getId());
		productDTO.setId(product.getId());
		productDTO.setName(product.getName());
		productDTO.setPrice(product.getPrice());
		productDTO.setDescription(product.getDescription());
		productDTO.setKeywords(product.getKeywords());
		productDTO.setShort_desc(product.getShort_desc());
		productDTO.setTechnical_specification(product.getTechnical_specification());
		productDTO.setUses(product.getUses());
		productDTO.setWarranty(product.getWarranty());
		productDTO.setWeight(product.getWeight());
		productDTO.setImageName(product.getImageName());
		productDTO.setModel(product.getModel());
		productDTO.setMrp(product.getMrp());
		productDTO.setSku(product.getSku());
		productDTO.setIs_tranding(product.getIs_tranding());
		productDTO.setIs_discounted(product.getIs_discounted());
		productDTO.setIs_featured(product.getIs_featured());
		productDTO.setIs_promo(product.getIs_promo());
		productDTO.setLead_time(product.getLead_time());
		model.addAttribute("categories", categoryservice.getAllCategories());
		model.addAttribute("subcategories", subcategoryservice.getAllSubCategories());
		model.addAttribute("taxes",taxservice.getAllTax());
		model.addAttribute("brands",brandservice.getAllBrands());
		model.addAttribute("sizes",sizeservice.getAllsize());
		model.addAttribute("colors",colorservice.getAllColor());
		model.addAttribute("coupons",couponservice.getAllCoupon());
		model.addAttribute("productDTO", productDTO);
		return "admin/productAdd";
	}

}
