package com.genius.AI_code.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.genius.AI_code.model.Product;
import com.genius.AI_code.repository.ProductRepository;

@Service
public class ProductService {

	@Autowired
	private ProductRepository productRepository;

	public void addProduct(Product product) {
		// TODO Auto-generated method stub
		productRepository.save(product);
	}

	public void removProductById(Long id) {
		// TODO Auto-generated method stub
		productRepository.deleteById(id);
	}
	
	public Product getProductById(Long id) {
		// TODO Auto-generated method stub
		return productRepository.getById(id);
	}
	public List <Product> getAllProducts() {
		// TODO Auto-generated method stub
		return productRepository.findAll();
	}
	
	
}
