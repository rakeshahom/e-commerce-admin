package com.genius.AI_code.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.genius.AI_code.model.Brand;
import com.genius.AI_code.repository.BrandRepository;

@Service
public class BrandService {

	@Autowired
	private BrandRepository brandRepository;

	public void addBrand(Brand brand) {
		// TODO Auto-generated method stub
		brandRepository.save(brand);
	}

	public List<Brand> getAllBrands() {
		// TODO Auto-generated method stub
		return brandRepository.findAll();
	}

	public void removbrandById(int id) {
		// TODO Auto-generated method stub
		brandRepository.deleteById(id);
	}
	
	public Brand getbrandById(int id) {
		// TODO Auto-generated method stub
		return brandRepository.getById(id);
	}
	
}
