package com.genius.AI_code.controller;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.genius.AI_code.model.Size;
import com.genius.AI_code.service.SizeService;

@Controller
@RequestMapping("/e-commerce/admin/")
public class SizeController {
	public static final String uploadDir = System.getProperty("user.dir") + "/src/main/resources/static/sizeImages";

	@Autowired
	private SizeService sizeService;

	

	@GetMapping("size/add")
	public String SizeAddGet(Model model) {
		model.addAttribute("size", new Size());
		return "admin/sizeAdd";
	}

	@PostMapping("size/add")
	public String sizeAddPost(@ModelAttribute("size") Size size,
			@RequestParam("sizeImage") MultipartFile file, @RequestParam("imgName") String imgName)
			throws IOException {
		size.setId(size.getId());
		size.setSize(size.getSize());
		size.setStatus(1);
		String imageUUID;
		if (!file.isEmpty()) {
			imageUUID = file.getOriginalFilename();

			Path fileNameAndPath = Paths.get(uploadDir, imageUUID);
			Files.write(fileNameAndPath, file.getBytes());
		} else {
			imageUUID = imgName;
		}
		size.setImageName(imageUUID);
		sizeService.addSize(size);
		return "redirect:/e-commerce/admin/size/add";
	}
	@GetMapping("size/delete/{id}")
	public String deleteSize(@PathVariable int id) {
		sizeService.removsizeById(id);
		return "redirect:/e-commerce/admin/size/manage";
	}
	@GetMapping("size/manage")
	public String sizeAddManage(Model model) {
		model.addAttribute("sizes", sizeService.getAllsize());
		return "admin/size_manage";
	}
	@GetMapping("size/update/{id}")
	public String updateSizeGet(@PathVariable int id,Model model)
			 {
		Size size=sizeService.getsizeById(id);
		size.setSize(size.getSize());
		size.setStatus(1);
		size.setImageName(size.getImageName());
		model.addAttribute("sizes", sizeService.getAllsize());
		model.addAttribute("size",size);
		return "admin/sizeAdd";
	}
	
}
