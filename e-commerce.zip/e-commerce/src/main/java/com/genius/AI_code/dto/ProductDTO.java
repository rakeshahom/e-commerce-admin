package com.genius.AI_code.dto;

import lombok.Data;
@Data
public class ProductDTO {
	private Long id;
	private String name;
	private String imageName;
	private int categoryId;
	private Long subcategoryId;
	private int taxId;
	private int brandId;
	private int sizeId;
	private int colorId;
	private int couponId;
	private String model;
	private double price;
	private double weight;
	private String description;
	private String short_desc;
	private String keywords;
	private String technical_specification;
	private String uses;
	private String warranty;
	private int status;
	private double mrp;
	private String sku;
	private String is_tranding;
	private double is_discounted;
	private String is_featured;
	private String is_promo;
	private String lead_time;
	
	
}
