package com.genius.AI_code.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.genius.AI_code.model.SubCategory;
import com.genius.AI_code.repository.SubCategoryRepository;

@Service
public class SubCategoryService {
	
	@Autowired
	private SubCategoryRepository subCategoryRepository;
	
	public void addsubCategory(SubCategory subcategory) {
		// TODO Auto-generated method stub
		subCategoryRepository.save(subcategory);
	}

	public void removsubCategoryById(Long id) {
		// TODO Auto-generated method stub
		subCategoryRepository.deleteById(id);
	}

	public List<SubCategory> getAllSubCategories() {
		// TODO Auto-generated method stub
		return subCategoryRepository.findAll();
	}

	public Optional<SubCategory> getSubCategoryById(Long id) {
		// TODO Auto-generated method stub
		return subCategoryRepository.findById(id);
	}
	public List<SubCategory> getAllSubCategoryByCategoryId(Long id) {
		return subCategoryRepository.findAllByCategory_Id(id);
	}
	
}
