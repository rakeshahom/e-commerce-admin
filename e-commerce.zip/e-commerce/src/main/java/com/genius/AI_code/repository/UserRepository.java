package com.genius.AI_code.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.genius.AI_code.model.User;

public interface UserRepository extends JpaRepository<User, Integer>{

	Optional<User>findUserByUsername(String username);
}
