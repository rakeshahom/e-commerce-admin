package com.genius.AI_code.controller;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.genius.AI_code.model.Brand;
import com.genius.AI_code.service.BrandService;

@Controller
@RequestMapping("/e-commerce/admin/")
public class BrandController {
	public static final String uploadDir = System.getProperty("user.dir") + "/src/main/resources/static/brandImages";

	@Autowired
	private BrandService brandService;

	

	@GetMapping("brand/add")
	public String brandAddGet(Model model) {
		model.addAttribute("brand", new Brand());
		return "admin/brandAdd";
	}

	@PostMapping("brand/add")
	public String brandAddPost(@ModelAttribute("brand") Brand brand,
			@RequestParam("brandImage") MultipartFile file, @RequestParam("imgName") String imgName)
			throws IOException {
		brand.setId(brand.getId());
		brand.setName(brand.getName());
		String imageUUID;
		if (!file.isEmpty()) {
			imageUUID = file.getOriginalFilename();

			Path fileNameAndPath = Paths.get(uploadDir, imageUUID);
			Files.write(fileNameAndPath, file.getBytes());
		} else {
			imageUUID = imgName;
		}
		brand.setImageName(imageUUID);
		brandService.addBrand(brand);
		return "redirect:/e-commerce/admin/brand/add";
	}
	@GetMapping("brand/delete/{id}")
	public String deleteBrand(@PathVariable int id) {
		brandService.removbrandById(id);
		return "redirect:/e-commerce/admin/brand/manage";
	}
	@GetMapping("brand/manage")
	public String brandAddManage(Model model) {
		model.addAttribute("brands", brandService.getAllBrands());
		return "admin/brand_manage";
	}
	@GetMapping("brand/update/{id}")
	public String updateBrandGet(@PathVariable int id,Model model)
			 {
		Brand brand=brandService.getbrandById(id);
		brand.setName(brand.getName());
		brand.setImageName(brand.getImageName());
		model.addAttribute("brands", brandService.getAllBrands());
		model.addAttribute("brand",brand);
		return "admin/brandAdd";
	}
}
