package com.genius.AI_code.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import lombok.Data;

@Data
@Entity
public class Product {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "product_id")
	private Long id;
	private String name;
	private String imageName;
	private double price;
	private double weight;
	private String description;
	private String short_desc;
	private String keywords;
	private String technical_specification;
	private String uses;
	private String warranty;
	private String status;
	private String model;
	private double mrp;
	private String sku;
	private String is_tranding;
	private double is_discounted;
	private String is_featured;
	private String is_promo;
	private String lead_time;
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "category_id", referencedColumnName = "category_id")
	private Category category;
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "subcategory_id", referencedColumnName = "subcategory_id")
	private SubCategory subcategory;
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "tax_id", referencedColumnName = "tax_id")
	private Tax tax;
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "brand_id", referencedColumnName = "brand_id")
	private Brand brand;
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "size_id", referencedColumnName = "size_id")
	private Size size;
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "color_id", referencedColumnName = "color_id")
	private Color color;
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "coupon_id", referencedColumnName = "coupon_id")
	private Coupon couponId;
	

}
