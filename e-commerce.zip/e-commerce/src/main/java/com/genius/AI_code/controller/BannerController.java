package com.genius.AI_code.controller;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.genius.AI_code.model.Banner;
import com.genius.AI_code.model.Size;
import com.genius.AI_code.service.BannerService;

@Controller
@RequestMapping("/e-commerce/admin/")
public class BannerController {
	public static final String uploadDir = System.getProperty("user.dir") + "/src/main/resources/static/bannerImages";

	@Autowired
	private BannerService bannerService;

	

	@GetMapping("banner/add")
	public String BannerAddGet(Model model) {
		model.addAttribute("banner", new Banner());
		return "admin/bannerAdd";
	}

	@PostMapping("banner/add")
	public String bannerAddPost(@ModelAttribute("banner") Banner banner,
			@RequestParam("bannerImage") MultipartFile file, @RequestParam("imgName") String imgName)
			throws IOException {
		banner.setId(banner.getId());
		banner.setBannername(banner.getBannername());
		banner.setStatus(1);
		String imageUUID;
		if (!file.isEmpty()) {
			imageUUID = file.getOriginalFilename();

			Path fileNameAndPath = Paths.get(uploadDir, imageUUID);
			Files.write(fileNameAndPath, file.getBytes());
		} else {
			imageUUID = imgName;
		}
		banner.setImageName(imageUUID);
		bannerService.addBanner(banner);
		return "redirect:/e-commerce/admin/banner/add";
	}
	@GetMapping("banner/delete/{id}")
	public String deleteBanner(@PathVariable int id) {
		bannerService.removbannerById(id);
		return "redirect:/e-commerce/admin/banner/manage";
	}
	@GetMapping("banner/manage")
	public String bannerManage(Model model) {
		model.addAttribute("banners", bannerService.getAllbanner());
		return "admin/banner_manage";
	}
	@GetMapping("banner/update/{id}")
	public String updateBannerGet(@PathVariable int id,Model model)
			 {
		Banner banner=bannerService.getbannerById(id);
		banner.setBannername(banner.getBannername());
		banner.setStatus(1);
		banner.setImageName(banner.getImageName());
		model.addAttribute("banners", bannerService.getAllbanner());
		model.addAttribute("banner",banner);
		return "admin/bannerAdd";
	}
	
}
