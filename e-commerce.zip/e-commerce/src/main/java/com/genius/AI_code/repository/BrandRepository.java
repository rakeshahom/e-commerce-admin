package com.genius.AI_code.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.genius.AI_code.model.Brand;

@Repository
public interface BrandRepository extends JpaRepository<Brand, Integer>{

}
