package com.genius.AI_code.dto;

import lombok.Data;

@Data
public class SubCategoryDTO {
	private Long id;
	private String name;
	private String imageName;
	private int categoryId;
}
