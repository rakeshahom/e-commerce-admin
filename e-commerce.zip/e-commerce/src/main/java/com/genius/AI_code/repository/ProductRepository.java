package com.genius.AI_code.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.genius.AI_code.model.Product;
import com.genius.AI_code.model.SubCategory;

@Repository
public interface ProductRepository extends JpaRepository<Product, Long>{

	List<SubCategory> findAllByCategory_Id(Long id);

}
