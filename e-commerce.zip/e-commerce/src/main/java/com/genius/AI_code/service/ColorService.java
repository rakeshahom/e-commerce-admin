package com.genius.AI_code.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.genius.AI_code.model.Color;
import com.genius.AI_code.repository.ColorRepository;

@Service
public class ColorService {

	@Autowired
	private ColorRepository colorRepository;

	public void addColor(Color color) {
		// TODO Auto-generated method stub
		colorRepository.save(color);
	}

	public List<Color> getAllColor() {
		// TODO Auto-generated method stub
		return colorRepository.findAll();
	}

	public void removColorById(int id) {
		// TODO Auto-generated method stub
		colorRepository.deleteById(id);
	}
	
	public Color getColorById(int id) {
		// TODO Auto-generated method stub
		return colorRepository.getById(id);
	}

	
	
}
