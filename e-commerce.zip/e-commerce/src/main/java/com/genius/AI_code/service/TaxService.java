package com.genius.AI_code.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.genius.AI_code.model.Tax;
import com.genius.AI_code.repository.TaxRepository;

@Service
public class TaxService {

	@Autowired
	private TaxRepository taxRepository;

	public void addTax(Tax tax) {
		// TODO Auto-generated method stub
		taxRepository.save(tax);
	}

	public List<Tax> getAllTax() {
		// TODO Auto-generated method stub
		return taxRepository.findAll();
	}

	public void removTaxById(int id) {
		// TODO Auto-generated method stub
		taxRepository.deleteById(id);
	}
	
	public Tax getTaxById(int id) {
		// TODO Auto-generated method stub
		return taxRepository.getById(id);
	}

	
	
}
