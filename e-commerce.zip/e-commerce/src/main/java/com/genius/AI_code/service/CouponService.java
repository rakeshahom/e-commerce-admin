package com.genius.AI_code.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.genius.AI_code.model.Coupon;
import com.genius.AI_code.repository.CouponRepository;

@Service
public class CouponService {

	@Autowired
	private CouponRepository couponRepository;

	public void addCoupon(Coupon coupon) {
		// TODO Auto-generated method stub
		couponRepository.save(coupon);
	}

	public List<Coupon> getAllCoupon() {
		// TODO Auto-generated method stub
		return couponRepository.findAll();
	}

	public void removCouponById(int id) {
		// TODO Auto-generated method stub
		couponRepository.deleteById(id);
	}
	
	public Coupon getCouponById(int id) {
		// TODO Auto-generated method stub
		return couponRepository.getById(id);
	}

	
	
}
